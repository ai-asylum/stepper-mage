# playable-kit

Shared toolkit for ai-asylum **MRAID playable ads**. One implementation of the
build/embed/verify pipeline every game was previously hand-rolling; per game,
only an **asset manifest** (and a 5-line vite config) differs.

The contract it enforces is team-dashboard's marketing-readiness spec
(`ai-asylum/team-dashboard` → `docs/marketing-readiness.md`): **one
self-contained HTML ≤ 5 MB, MRAID present, a CTA to the store, and no external
requests** beyond `mraid.js` and Google Fonts.

> This repo is public so the private game repos can consume it as a plain
> `github:` npm dependency and call its reusable workflow without any auth
> setup. It contains generic tooling only — no game code or assets.

## Install (in a game repo)

```bash
npm i -D github:ai-asylum/playable-kit#v1
```

## 1. Runtime shim — `playable-kit/runtime`

The only kit code that ships in the game bundle. The game resolves every
runtime-fetched asset through it; outside a playable bundle everything falls
through untouched (zero behavior change on web/Android).

```js
import { withPlayableAssets, assetUrl } from 'playable-kit/runtime';

// three.js loaders (covers the model AND its external textures):
const loader = new GLTFLoader(withPlayableAssets(new THREE.LoadingManager()));

// plain <img>/<audio> srcs:
img.src = assetUrl('/assets/ui/happy-cat.png');
```

## 2. Vite config — `playable-kit/vite`

```js
// vite.playable.config.js
import { playableConfig } from 'playable-kit/vite';
export default playableConfig({
  entry: 'ads/playable-src/index.html',
  // per-game extras: plugins: [react()], define: { __PLAYABLE__: 'true' }
});
```

## 3. Build script — `playable-kit/build`

```js
// scripts/build-playable.mjs — the game's ASSET MANIFEST lives here.
import { buildPlayable } from 'playable-kit/build';

buildPlayable({
  root, // repo root
  config: 'vite.playable.config.js',
  entry: 'ads/playable-src/index.html',
  out: 'ads/playable/index.html',
  assets: [
    { file: 'public/pets/animal-cat.glb', key: 'pets/animal-cat.glb' },
    // …every asset the trimmed ad experience fetches at runtime
  ],
  globals: { __PLAYABLE_PETS__: ['cat'] }, // optional extra window globals
  forceQuery: { ad: '1' },                 // optional boot-time query params
});
```

Wire it as `"build:playable": "node scripts/build-playable.mjs"`.

## 4. CI — reusable workflow

```yaml
# .github/workflows/playable.yml (in the game repo)
name: Playable
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]
jobs:
  playable:
    uses: ai-asylum/playable-kit/.github/workflows/playable-check.yml@v1
    permissions:
      contents: write
```

Every build **rebuilds the playable from source** and runs the **behavioral
smoke test** (`playable-smoke`): loads the file over `file://` in headless
Chromium and asserts a canvas renders, zero page errors, zero disallowed
http(s) requests. On `push`, a stale committed artifact is replaced by a fresh
rebuild commit (`[skip ci]`); on PRs it fails the check instead. This is the
check the dashboard's regexes can't do — they once passed a "playable" that
contained no game code at all.
